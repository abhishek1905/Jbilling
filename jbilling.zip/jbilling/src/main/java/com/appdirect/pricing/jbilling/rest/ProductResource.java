package com.appdirect.pricing.jbilling.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appdirect.pricing.jbilling.PricingReponse;
import com.appdirect.pricing.jbilling.domain.Product;
import com.appdirect.pricing.jbilling.repository.ProductRepository;

@RestController
@RequestMapping("/product")
public class ProductResource {

	@Autowired
	private ProductRepository productRepository;
	
	@PostMapping
	public PricingReponse<Product> storeProduct(@RequestBody Product product){
		
		PricingReponse<Product> reponse= new PricingReponse<>();
		Product productResponse = productRepository.save(product);
		reponse.setMessage("Successful");
		reponse.setStatus(HttpStatus.CREATED.toString());
		reponse.setPayload(productResponse);
	return reponse;
		
		
		
	}
	
}
