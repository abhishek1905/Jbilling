package com.appdirect.pricing.jbilling.service;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;

@RunWith(PowerMockRunner.class)
@PrepareForTest({}) 
public class IdealPriceCalculatorImplTest {


	@Before
	public void initializeMockito() {
		MockitoAnnotations.initMocks(this);
	} 
	
}
