package com.appdirect.pricing.jbilling.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity @IdClass(ProductInStoreId.class)
public class ProductInStore {
	
	@Column
	@Id
	private long product;
	
	@Column
	private double price;
	
	@Column
	private String notes;

	
	@Column
	@Id
	private long store;
	
	public long getStore() {
		return store;
	}

	public void setStore(long store) {
		this.store = store;
	}

	public long getProduct() {
		return product;
	}

	public void setProduct(long product) {
		this.product = product;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	
}
