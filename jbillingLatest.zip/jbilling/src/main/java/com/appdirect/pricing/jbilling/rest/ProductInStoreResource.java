package com.appdirect.pricing.jbilling.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appdirect.pricing.jbilling.PricingReponse;
import com.appdirect.pricing.jbilling.domain.ProductInStore;

import com.appdirect.pricing.jbilling.repository.ProductInStoreRepository;
import com.appdirect.pricing.jbilling.utilities.ResponseBuilder;


	
	
	

@RestController
@RequestMapping("/store/product")
public class ProductInStoreResource {
	
	@Autowired
	private ProductInStoreRepository productStoreRepository;
	
	@Autowired
	private ResponseBuilder<ProductInStore> responseBuilder;
	
	@PostMapping
	public PricingReponse<ProductInStore> saveStore(@RequestBody ProductInStore productstore)
	{
		
		ProductInStore storeResponse=productStoreRepository.save(productstore);
		
		return responseBuilder.buildResponse(storeResponse);
		
		
	}
	
	

}


