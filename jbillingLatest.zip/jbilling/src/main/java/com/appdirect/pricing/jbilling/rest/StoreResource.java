package com.appdirect.pricing.jbilling.rest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appdirect.pricing.jbilling.PricingReponse;
import com.appdirect.pricing.jbilling.domain.Store;
import com.appdirect.pricing.jbilling.repository.StoreRepository;
import com.appdirect.pricing.jbilling.utilities.ResponseBuilder;


@RestController
@RequestMapping("/store")
public class StoreResource {
	
	@Autowired
	private StoreRepository storeRepository;
	
	@Autowired
	private ResponseBuilder<Store> responseBuilder;
	
	@PostMapping
	public PricingReponse<Store> saveStore(@RequestBody Store store)
	{
		
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		store.setCreated(dateFormat.format(date));
		Store storeResponse=storeRepository.save(store);
		
		return responseBuilder.buildResponse(storeResponse);
		
		
	}
	
	

}
