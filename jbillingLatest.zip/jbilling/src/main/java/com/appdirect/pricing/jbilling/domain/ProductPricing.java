package com.appdirect.pricing.jbilling.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.ConstructorResult;
import org.springframework.stereotype.Service;
import javax.persistence.ColumnResult;



@Entity

@SqlResultSetMapping(
        name = "ProductPricingMapping",
        classes = @ConstructorResult(
                targetClass = ProductPricing.class,
                columns = {
                    @ColumnResult(name = "product_Id", type = Long.class),
                    @ColumnResult(name = "name")
                    }))

@NamedNativeQuery(name="ProductPricing.getPricing", query="SELECT PRODUCT_ID, name from Product ", resultSetMapping="ProductPricingMapping")

public class ProductPricing implements Serializable {
	
	
	
	public ProductPricing() {
		super();
	}

	public ProductPricing(long product, String name) {
		super();
		this.product = product;
		this.name = name;
	}

	@Column(name="product_Id")
	@Id
	private long product;
	
	private long store;
	
	private String description;
	
	@Column
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column
	private double basePrice;
	
	private double averagePrice;
	
	private double lowestPrice;
	
	private double highestPrice;
	
	private double idealPrice;
	
	private int count;

	public long getProduct() {
		return product;
	}

	public void setProduct(long product) {
		this.product = product;
	}

	public long getStore() {
		return store;
	}

	public void setStore(long store) {
		this.store = store;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public double getLowestPrice() {
		return lowestPrice;
	}

	public void setLowestPrice(double lowestPrice) {
		this.lowestPrice = lowestPrice;
	}

	public double getHighestPrice() {
		return highestPrice;
	}

	public void setHighestPrice(double highestPrice) {
		this.highestPrice = highestPrice;
	}

	public double getIdealPrice() {
		return idealPrice;
	}

	public void setIdealPrice(double idealPrice) {
		this.idealPrice = idealPrice;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	

}

