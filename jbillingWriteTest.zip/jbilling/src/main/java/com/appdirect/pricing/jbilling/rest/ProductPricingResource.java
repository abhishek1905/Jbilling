package com.appdirect.pricing.jbilling.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appdirect.pricing.jbilling.PricingReponse;
import com.appdirect.pricing.jbilling.domain.ProductInStore;
import com.appdirect.pricing.jbilling.domain.ProductPricing;
import com.appdirect.pricing.jbilling.repository.ProductPricingRepository;
import com.appdirect.pricing.jbilling.utilities.ResponseBuilder;

@RestController
@RequestMapping("product/{product-id}/prices")
public class ProductPricingResource {
	
	@Autowired
	private ProductPricingRepository pricingRepository;
	
	@Autowired
	private ResponseBuilder<ProductPricing> responseBuilder;
	
	@GetMapping
	public PricingReponse<ProductPricing> getPrices(@PathVariable("product-id") long productId)
	{
		
		System.out.println("path param "+productId);
		ProductPricing pricingResponse=pricingRepository.getPricing(productId);
		
		return responseBuilder.buildResponse(pricingResponse);
		
		
	}
	
	
	
	
	

}
