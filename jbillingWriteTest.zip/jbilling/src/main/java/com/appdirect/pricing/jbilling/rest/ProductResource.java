package com.appdirect.pricing.jbilling.rest;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appdirect.pricing.jbilling.PricingReponse;
import com.appdirect.pricing.jbilling.domain.Product;
import com.appdirect.pricing.jbilling.domain.Store;
import com.appdirect.pricing.jbilling.repository.ProductRepository;
import com.appdirect.pricing.jbilling.utilities.CurrentDate;
import com.appdirect.pricing.jbilling.utilities.ResponseBuilder;

@RestController
@RequestMapping("/product")
public class ProductResource {

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ResponseBuilder<Product> responseBuilder;
	
	@PostMapping
	public PricingReponse<Product> storeProduct(@RequestBody Product product){
		
		
		
		product.setCreated(new CurrentDate().getDate());
		Product productResponse = productRepository.save(product);
		
		return responseBuilder.buildResponse(productResponse);
		
		
		
		
	}
	
}
