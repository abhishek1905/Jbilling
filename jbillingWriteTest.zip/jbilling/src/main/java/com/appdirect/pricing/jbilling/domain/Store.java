package com.appdirect.pricing.jbilling.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Store implements Serializable{
	
	public Store() {
		super();
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long storeId;
	
	@Column
	private String name;
	
	@Column
	private String description;
	
	@Column
	private String created;

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public long getStoreId() {
		return storeId;
	}

	public Store(String name, String description, String created) {
		super();
		
		this.name = name;
		this.description = description;
		this.created = created;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
