package com.appdirect.pricing.jbilling.Service;

import java.util.Collection;
import java.util.TreeSet;

public class IdealPriceCalculatorImpl implements IdealPriceCalculator{
	
	private TreeSet<Double> prices;
	private double sum=0;
	private int count=1; 
	
	@Override
	public double getIdealPrice(Collection<Double> prices)
	{
		this.prices=new TreeSet<Double>(new PriceComparator<Double>());
		this.prices.addAll(prices);
		
		int size=prices.size();
		for(double price: prices){
			if(count==1||count==2||count==size-1||count==size){
				count++;
				continue;	
			}
				
			
			sum=sum+price;
			
			count++;
			
			
		}
		double average=sum/(size-4);
		return (average + average*(20/100));
		
	}
	

}
