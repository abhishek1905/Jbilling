package com.appdirect.pricing.jbilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JbillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JbillingApplication.class, args);
	}
}
