package com.appdirect.pricing.jbilling;

import java.io.Serializable;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class PricingReponse<T> implements Serializable {

	private String status;
	private String message;
	private T payload;
	
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = (T) payload;
	}
	
}
