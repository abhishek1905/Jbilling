package com.appdirect.pricing.jbilling.utilities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.appdirect.pricing.jbilling.PricingReponse;

@Service
public class ResponseBuilder<T> {
	
	@Autowired
	private PricingReponse<T> response;
	
	public PricingReponse<T> buildResponse(T repoResponse)
	{
		if(repoResponse==null)
		{
		
			response.setMessage("failure");
			response.setStatus(HttpStatus.BAD_REQUEST.toString());
		}
		else{
			
			
			response.setMessage("success");
			response.setStatus(HttpStatus.CREATED.toString());
			response.setPayload(repoResponse);
			
			
		}
		return response;
		
	}
	
	
	

}
