package com.appdirect.pricing.jbilling.Service;

import java.util.Comparator;

public class PriceComparator<T extends Comparable<T>> implements Comparator<T>{
	
	@Override
	public int compare(T price1,T price2){
		
		if(price1.compareTo(price2)==0)
			return -1;
		else 
			return price1.compareTo(price2);
	}

	
	

}
