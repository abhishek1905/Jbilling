package com.appdirect.pricing.jbilling.Service;

import java.util.Collection;

public interface IdealPriceCalculator {
	public double getIdealPrice(Collection<Double> priceList);

}
