package com.appdirect.pricing.jbilling.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


import com.appdirect.pricing.jbilling.domain.ProductPricing;

public interface ProductPricingRepository extends CrudRepository<ProductPricing, Long> {
	
	
	
	public ProductPricing getPricing(@Param("productId") long productId);
	
	
	
	

}
