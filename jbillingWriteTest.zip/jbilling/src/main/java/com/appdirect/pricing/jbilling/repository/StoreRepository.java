package com.appdirect.pricing.jbilling.repository;

import org.springframework.data.repository.CrudRepository;
import com.appdirect.pricing.jbilling.domain.Product;
import com.appdirect.pricing.jbilling.domain.Store;

public interface StoreRepository extends CrudRepository<Store, Long> {
	

}
