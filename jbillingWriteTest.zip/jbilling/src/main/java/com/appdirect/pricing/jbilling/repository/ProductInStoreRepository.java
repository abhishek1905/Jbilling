package com.appdirect.pricing.jbilling.repository;



import org.springframework.data.repository.CrudRepository;

import com.appdirect.pricing.jbilling.domain.ProductInStore;



public interface ProductInStoreRepository extends CrudRepository<ProductInStore, Long> {

	
	
}
