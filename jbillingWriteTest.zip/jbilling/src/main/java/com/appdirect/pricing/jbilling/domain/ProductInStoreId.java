package com.appdirect.pricing.jbilling.domain;

import java.io.Serializable;

public class ProductInStoreId implements Serializable {

	private long product;

	private long store;

}
