package com.appdirect.pricing.jbilling.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.ConstructorResult;

import javax.persistence.ColumnResult;

@Entity

@SqlResultSetMapping(name = "ProductPricingMapping", classes = @ConstructorResult(targetClass = ProductPricing.class, columns = {
		@ColumnResult(name = "product_Id", type = Long.class), @ColumnResult(name = "name"),
		@ColumnResult(name = "description"),@ColumnResult(name = "base_Price" ,type = Double.class),@ColumnResult(name = "averagePrice",type = Double.class),
		@ColumnResult(name = "lowestPrice",type = Double.class),
		@ColumnResult(name = "highestPrice",type = Double.class),
		@ColumnResult(name = "count",type = Integer.class)
		}))

@NamedNativeQuery(name = "ProductPricing.getPricing", query = "SELECT p.PRODUCT_ID, p.name, p.description,p.base_Price,ps.averagePrice,ps.lowestPrice,ps.highestPrice,ps.count"
		+ " from "
		+ "Product p INNER JOIN (SELECT Product,  AVG(price) as averagePrice, MIN(PRICE) as lowestPrice,MAX(price) as highestPrice,COUNT(price) as count"
		+ " FROM Product_In_Store GROUP BY Product HAVING Product=:productId) ps ON p.product_Id=ps.product ", resultSetMapping = "ProductPricingMapping")

public class ProductPricing implements Serializable {

	public ProductPricing(long product, String name, String description, double base_Price, double averagePrice,
			double lowestPrice, double highestPrice, int count) {
		
		this.product = product;
		this.name = name;
		this.description = description;
		this.basePrice = base_Price;
		this.averagePrice = averagePrice;
		this.lowestPrice = lowestPrice;
		this.highestPrice = highestPrice;
		
		this.count = count;
	}

	

	public ProductPricing() {
		super();
	}

	public ProductPricing(long product, String name) {
		super();
		this.product = product;
		this.name = name;
	}

	@Column(name = "product_Id")
	@Id
	private long product;
	@Column(name = "name")
	private String name;
	@Column(name = "description")
	private String description;
	@Column(name = "base_Price")
	private double basePrice;
	@Column(name = "averagePrice")
	private double averagePrice;
	@Column(name = "lowestPrice")
	private double lowestPrice;
	@Column(name = "highestPrice")
	private double highestPrice;
	@Column(name = "idealPrice")
	private double idealPrice;
	@Column(name = "count")
	private int count;
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	

	public long getProduct() {
		return product;
	}

	public void setProduct(long product) {
		this.product = product;
	}

	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public double getLowestPrice() {
		return lowestPrice;
	}

	public void setLowestPrice(double lowestPrice) {
		this.lowestPrice = lowestPrice;
	}

	public double getHighestPrice() {
		return highestPrice;
	}

	public void setHighestPrice(double highestPrice) {
		this.highestPrice = highestPrice;
	}

	public double getIdealPrice() {
		return idealPrice;
	}

	public void setIdealPrice(double idealPrice) {
		this.idealPrice = idealPrice;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
