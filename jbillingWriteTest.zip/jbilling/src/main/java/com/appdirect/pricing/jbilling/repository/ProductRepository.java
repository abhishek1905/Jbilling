package com.appdirect.pricing.jbilling.repository;

import org.springframework.data.repository.CrudRepository;

import com.appdirect.pricing.jbilling.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {

	
	
}
