package com.appdirect.pricing.jbilling.repositoryTest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.test.context.junit4.SpringRunner;
import static org.assertj.core.api.Assertions.assertThat;

import com.appdirect.pricing.jbilling.domain.Product;
import com.appdirect.pricing.jbilling.repository.ProductRepository;
import com.appdirect.pricing.jbilling.utilities.CurrentDate;


@RunWith(SpringRunner.class)
@DataJpaTest
public class ProductRepositoryTest {
	
	

	@Autowired
	ProductRepository repository;
	
	@Test
	public void ProductRepository_should_store_a_Product() {
		Product product = repository.save(intializeProduct());
 
		assertThat(product).hasFieldOrPropertyWithValue("productId", 1L);
		assertThat(product).hasFieldOrPropertyWithValue("name", "Pen drive");
		assertThat(product).hasFieldOrPropertyWithValue("description", "Portable device");
		assertThat(product).hasFieldOrPropertyWithValue("basePrice", 800.0);
		assertThat(product).hasFieldOrPropertyWithValue("created", new CurrentDate().getDate());
	}
	
	private Product intializeProduct()
	{
		Product product=new Product();
		product.setName("Pen drive");
		product.setDescription("Portable device");
		product.setBasePrice(800);
		product.setCreated(new CurrentDate().getDate());
		return product;
		
	}

}
