package com.appdirect.pricing.jbilling.repositoryTest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.appdirect.pricing.jbilling.domain.Product;
import com.appdirect.pricing.jbilling.domain.ProductInStore;
import com.appdirect.pricing.jbilling.domain.ProductPricing;
import com.appdirect.pricing.jbilling.domain.Store;
import com.appdirect.pricing.jbilling.repository.ProductPricingRepository;


@RunWith(SpringRunner.class)
@DataJpaTest
public class ProductPricingRepositoryTest {
	
	@Autowired
	private TestEntityManager entityManager;
 
	@Autowired
	ProductPricingRepository productPricingrepository;
	
	
	
	
	@Test
	public void ProductPricingRepository_should_giveProductPrices() {
		
		   
		intializeProductAndStore();
		ProductPricing productPricing= productPricingrepository.getPricing(1L);
 
		assertThat(productPricing).hasFieldOrPropertyWithValue("product", 1L);
		assertThat(productPricing).hasFieldOrPropertyWithValue("name", "pen drive");
		assertThat(productPricing).hasFieldOrPropertyWithValue("description", "PORTABLE DEVICE");
		assertThat(productPricing).hasFieldOrPropertyWithValue("basePrice", 800.0);
		assertThat(productPricing).hasFieldOrPropertyWithValue("averagePrice", 975.0);
		assertThat(productPricing).hasFieldOrPropertyWithValue("lowestPrice", 800.00);
		assertThat(productPricing).hasFieldOrPropertyWithValue("highestPrice", 1200.0);
		assertThat(productPricing).hasFieldOrPropertyWithValue("count", 4);
	}
	
	private void intializeProductAndStore()
	{
		entityManager.persist(new Product("PORTABLE DEVICE","pen drive",800,""));
		entityManager.persist(new Store("DMART","MALL",""));
		entityManager.persist(new Store("MAX","MALL",""));
		entityManager.persist(new Store("SCANDISK","MALL",""));
		entityManager.persist(new Store("NEWTON","MALL",""));
		entityManager.persist(new ProductInStore(1,1,800.0,"notes",""));
		entityManager.persist(new ProductInStore(1,2,900,"notes",""));
		entityManager.persist(new ProductInStore(1,3,1000,"notes",""));
		entityManager.persist(new ProductInStore(1,4,1200,"notes",""));
		
		
		
		
	}
		
	
	

}
