package com.appdirect.pricing.jbilling.repositoryTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.test.context.junit4.SpringRunner;

import com.appdirect.pricing.jbilling.domain.ProductInStore;

import com.appdirect.pricing.jbilling.repository.ProductInStoreRepository;

import com.appdirect.pricing.jbilling.utilities.CurrentDate;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ProductInStoreRepositoryTest {
	
	@Autowired
	ProductInStoreRepository repository;
	
	@Test
	public void ProductInStoreRepository_should_store_a_ProductInStore() {
		ProductInStore productStore= repository.save(intializeProductInStore());
 
		assertThat(productStore).hasFieldOrPropertyWithValue("product", 1L);
		assertThat(productStore).hasFieldOrPropertyWithValue("store", 1L);
		assertThat(productStore).hasFieldOrPropertyWithValue("price", 800.0);
		
		assertThat(productStore).hasFieldOrPropertyWithValue("created", new CurrentDate().getDate());
	}
	
	private ProductInStore intializeProductInStore()
	{
		ProductInStore productStore=new ProductInStore();
		productStore.setProduct(1L);
		productStore.setStore(1L);
		productStore.setPrice(800);
		productStore.setNotes("Price for Pen drive in DMART");
		productStore.setCreated(new CurrentDate().getDate());
		return productStore;
		
	}


}
