package com.appdirect.pricing.jbilling.rest;
import static org.junit.Assert.*;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.appdirect.pricing.jbilling.domain.Product;
import com.appdirect.pricing.jbilling.repository.ProductRepository;
import com.appdirect.pricing.jbilling.rest.ProductResource;
import com.appdirect.pricing.jbilling.utilities.ResponseBuilder;


@RunWith(SpringRunner.class)

//@WebMvcTest(value = ProductResource.class, secure = false)
@SpringBootTest(classes=ProductResource.class)

public class ProductResourceTest {
	
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private ProductRepository productService;
	
	@Autowired
	private ResponseBuilder<Product> responseBuilder;
	
	@InjectMocks
	private ProductResource productResource;
	
	
	@Test
	public void storeProductTest() throws Exception
	{
		final String productRequestJson = "{\"name\":\"pen-drive\",\"description\":\"Portable device\",\"basePrice\":800}";
		
		Mockito.when(
				productService.save(Mockito.any(Product.class))).thenReturn(mockProduct());
		
		// Send product as body to /product 
				RequestBuilder requestBuilder = MockMvcRequestBuilders
						.post("/product")
						.accept(MediaType.APPLICATION_JSON).content(productRequestJson)
						.contentType(MediaType.APPLICATION_JSON);
				
				MvcResult result = mockMvc.perform(requestBuilder).andReturn();

				MockHttpServletResponse response = result.getResponse();

				assertEquals(HttpStatus.CREATED.value(), response.getStatus());

				
				
				
		
		
	}

	private Product mockProduct() {
		Product mockProduct=new Product();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		
		mockProduct.setProductId(1);
		mockProduct.setBasePrice(800);
		mockProduct.setDescription("Portable device");
		mockProduct.setName("pen-drive");
		mockProduct.setCreated(dateFormat.format(date));
		return mockProduct;
	}
	
	
	

}
