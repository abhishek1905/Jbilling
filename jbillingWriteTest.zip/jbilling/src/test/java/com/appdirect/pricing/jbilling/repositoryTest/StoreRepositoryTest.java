package com.appdirect.pricing.jbilling.repositoryTest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.test.context.junit4.SpringRunner;
import static org.assertj.core.api.Assertions.assertThat;

import com.appdirect.pricing.jbilling.domain.Store;

import com.appdirect.pricing.jbilling.repository.StoreRepository;

import com.appdirect.pricing.jbilling.utilities.CurrentDate;

@RunWith(SpringRunner.class)
@DataJpaTest
public class StoreRepositoryTest {
	
	@Autowired
	StoreRepository repository;
	
	@Test
	public void StoreRepository_should_store_a_Store() {
		Store store= repository.save(intializeStore());
 
		assertThat(store).hasFieldOrPropertyWithValue("storeId", 1L);
		assertThat(store).hasFieldOrPropertyWithValue("name", "D MART");
		assertThat(store).hasFieldOrPropertyWithValue("description", "MALL");
		
		assertThat(store).hasFieldOrPropertyWithValue("created", new CurrentDate().getDate());
	}
	
	private Store intializeStore()
	{
		Store store=new Store();
		store.setName("D MART");
		store.setDescription("MALL");
		store.setCreated(new CurrentDate().getDate());
		return store;
		
	}


}
